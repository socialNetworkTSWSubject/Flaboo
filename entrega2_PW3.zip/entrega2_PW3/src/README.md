TSW_Project
===========

Se trata de desarrollar una aplicación web que implemente una pequeña red social estilo Facebook. Básicamente, la red social deberá permitir el registro de usuarios, el establecimiento de las relaciones de amistad, compartir pequeños textos o posts en el "muro" del usuario e indicar si un post gusta (like) o no.
