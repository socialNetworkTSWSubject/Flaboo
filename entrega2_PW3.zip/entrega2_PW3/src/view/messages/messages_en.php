<?php
  //file: /view/messages/messages_en.php
  $i18n_messages = 
  array( 
    "Buscar Amigos" => "Find friends",
    "Nuevo Post" => "New Post",
    "Enviar" => "Send",
    "PUBLICACIONES" => "PUBLICATIONS",
    "Comentado el" => "Commented on the",
    "a las" => "at",
    "Amigos" => "Friends",
    "Solicitudes Amistad" => "Friend Requests",
	"PUBLICACIONES" => "PUBLICATIONS",
    "Mis amigos" => "My friends",
    "Eliminar de amigos" => "Remove from friends",
    "Solicitudes pendientes" => "Pending applications",
    "Aceptar" => "Accept",
    "Rechazar" => "Turn down",
    "Usuarios" => "Users",
	"Enviar solicitud de amistad" => "Send friend request",
	"Correo electronico:" => "Email:",
    "Password:" => "Password:",
	"Repetir password:" => "Repeat password:",
    "Entrar" => "Enter",
    "Aun no te has registrado" => "Yet you have not registered",
	"Registrate en" => "Register for",
	"Registrate!" => "Register!",
    "Nombre y Apellidos:" => "Name and surname:",
	"Contacta con nosotros!" => "Contact us",
	"Nuevo Post:" => "New Post:",
	"Me gusta" => "Like",
	"Enviar" => "Submit",
	"Muro vacio" => "Empty wall"
  )
?>