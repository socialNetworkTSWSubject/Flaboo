Social Network FlaBoo

Autores del proyecto (PW3):
- Adri�n C�lix Fern�ndez
- Jenifer V�zquez Rey

Nota: El script sql para crear la base de datos se encuentra en el directorio /src/database
